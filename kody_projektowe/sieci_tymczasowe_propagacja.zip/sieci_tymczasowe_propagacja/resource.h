//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UniversalNetwork.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_UniversalNetworTYPE         129
#define ID_PERCOLATION_SIMULATION       32771
#define ID_PERCOLATION_SIMULATION32772  32772
#define ID_TEST_TEST                    32773
#define ID_TEST_CONVERTTONETWORK        32774
#define ID_TEST_BADAJSIECSKYROCK        32775
#define ID_POLYMOD_TEST                 32776
#define ID_POLYMOD_SYMULACJA            32777
#define ID_AGEDEGREE_SYMULACJA          32778
#define ID_AGEDEGREE_TEST               32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

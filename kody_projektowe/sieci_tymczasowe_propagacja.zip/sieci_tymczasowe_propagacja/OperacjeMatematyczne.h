#pragma once

class OperacjeMatematyczne
{
public:
	OperacjeMatematyczne(void);
	~OperacjeMatematyczne(void);
	int NajmniejszeKwadraty(double * daneX, double * daneY, int LiczbaDanych, double * a, double * bladA, double * b, double * bladB);
};
